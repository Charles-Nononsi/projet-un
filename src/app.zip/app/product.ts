export class Product {
  id: number;
  name: string;
  picture: string;
  types: string;
  prix : string;
  quantite : number;
  created: Date;
}
