import { Component} from '@angular/core';
import { Product } from './product';
import { PRODUCTS } from './mock-product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',

})
export class AppComponent  {
  }


