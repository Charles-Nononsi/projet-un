import { ProductTypeAvailablePipe } from './product-type-available.pipe';

describe('ProductTypeAvailablePipe', () => {
  it('create an instance', () => {
    const pipe = new ProductTypeAvailablePipe();
    expect(pipe).toBeTruthy();
  });
});
